#! /bin/bash

############################################################

# # Running IO/inputs/DLP/15-Puzzle/
cd IO/inputs/NLP/15-Puzzle/

p15Files=(`ls`)
num=${#p15Files[@]}
pre="IO/inputs/NLP/15-Puzzle/"
type=0  # NLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${p15Files[i]}, ${type}
    ./programsimplificationL ${pre}${p15Files[i]} ${type}
done



############################################################

# Running IO/inputs/NLP/Factoring/
cd IO/inputs/NLP/Factoring/

ifFiles=(`ls`)
num=${#ifFiles[@]}
pre="IO/inputs/NLP/Factoring/"
type=0  # NLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${ifFiles[i]}, ${type}
    ./programsimplificationL ${pre}${ifFiles[i]} ${type}
done


############################################################

# Running IO/inputs/NLP/labyrinth/
cd IO/inputs/NLP/labyrinth/

lbFiles=(`ls`)
num=${#lbFiles[@]}
pre="IO/inputs/NLP/labyrinth/"
type=0  # NLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${lbFiles[i]}, ${type}
    ./programsimplificationL ${pre}${lbFiles[i]} ${type}
done


############################################################

# Running IO/inputs/NLP/channelRouting/
cd IO/inputs/NLP/channelRouting/

crFiles=(`ls`)
num=${#crFiles[@]}
pre="IO/inputs/NLP/channelRouting/"
type=0    # NLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${crFiles[i]}, ${type}
    ./programsimplificationL ${pre}${crFiles[i]} ${type}
done


############################################################

# Running IO/inputs/DLP/Hampath/
cd IO/inputs/NLP/EqTest/

eqtfFiles=(`ls`)
num=${#eqtfFiles[@]}
pre="IO/inputs/NLP/EqTest/"
type=0  # NLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${eqtfFiles[i]}, ${type}
    ./programsimplificationL ${pre}${eqtfFiles[i]} ${type}
done


############################################################

# Running IO/inputs/DLP/HamiltonianPath/
cd IO/inputs/NLP/HamiltonianPath/

htpFiles=(`ls`)
num=${#htpFiles[@]}
pre="IO/inputs/NLP/HamiltonianPath/"
type=0  # NLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${htpFiles[i]}, ${type}
    ./programsimplificationL ${pre}${htpFiles[i]} ${type}
done


############################################################

# Running IO/inputs/DLP/RandomNonTight/
cd IO/inputs/NLP/RandomNonTight/

rntFiles=(`ls`)
num=${#rntFiles[@]}
pre="IO/inputs/NLP/RandomNonTight/"
type=0  # NLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${rntFiles[i]}, ${type}
    ./programsimplificationL ${pre}${rntFiles[i]} ${type}
done


############################################################

# Running IO/inputs/DLP/RLP-150/
cd IO/inputs/NLP/RLP-150/

r15Files=(`ls`)
num=${#r15Files[@]}
pre="IO/inputs/NLP/RLP-150/"
type=0  # NLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${r15Files[i]}, ${type}
    ./programsimplificationL ${pre}${r15Files[i]} ${type}
done


############################################################

# Running IO/inputs/DLP/RLP-200/
cd IO/inputs/NLP/RLP-200/

r20Files=(`ls`)
num=${#r20Files[@]}
pre="IO/inputs/NLP/RLP-200/"
type=0  # NLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${r20Files[i]}, ${type}
    ./programsimplificationL ${pre}${r20Files[i]} ${type}
done


############################################################

# Running IO/inputs/DLP/SchurNumbers/
cd IO/inputs/NLP/SchurNumbers/

snFiles=(`ls`)
num=${#snFiles[@]}
pre="IO/inputs/NLP/SchurNumbers/"
type=0  # NLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${snFiles[i]}, ${type}
    ./programsimplificationL ${pre}${snFiles[i]} ${type}
done


############################################################




############################################################
############################################################


############################################################

# Running IO/inputs/DLP/Mutex/
cd IO/inputs/DLP/Mutex/

mFiles=(`ls`)
num=${#mFiles[@]}
pre="IO/inputs/DLP/Mutex/"
type=1  # DLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${mFiles[i]}, ${type}
    ./programsimplificationL ${pre}${mFiles[i]} ${type}
done


############################################################

# Running IO/inputs/DLP/DisjunctiveLoops/
cd IO/inputs/DLP/DisjunctiveLoops/

dlFiles=(`ls`)
num=${#dlFiles[@]}
pre="IO/inputs/DLP/DisjunctiveLoops/"
type=1  # DLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${dlFiles[i]}, ${type}
    ./programsimplificationL ${pre}${dlFiles[i]} ${type}
done


############################################################

# Running IO/inputs/DLP/Hampath/
cd IO/inputs/DLP/Hampath/

hpFiles=(`ls`)
num=${#hpFiles[@]}
pre="IO/inputs/DLP/Hampath/"
type=1  # DLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${hpFiles[i]}, ${type}
    ./programsimplificationL ${pre}${hpFiles[i]} ${type}
done

############################################################

# Running IO/inputs/DLP/Hampath/
cd IO/inputs/DLP/RandomQuantifiedBooleanFormulas/

rqbfFiles=(`ls`)
num=${#rqbfFiles[@]}
pre="IO/inputs/DLP/RandomQuantifiedBooleanFormulas/"
type=1  # DLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${rqbfFiles[i]}, ${type}
    ./programsimplificationL ${pre}${rqbfFiles[i]} ${type}
done


############################################################

# Running IO/inputs/DLP/StrategicCompanies/
cd IO/inputs/DLP/StrategicCompanies/

scFiles=(`ls`)
num=${#scFiles[@]}
pre="IO/inputs/DLP/StrategicCompanies/"
type=1  # DLP


cd ../../../../
for ((i=0; i<num; i++));
do
    echo ${pre}${scFiles[i]}, ${type}
    ./programsimplificationL ${pre}${scFiles[i]} ${type}
done