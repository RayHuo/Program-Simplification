#! /bin/bash

./runLF.sh
./runL.sh